Heavy-ion_EM_fields
===================

calculate electromagnetic fields from the spectators in relativistic heavy-ion collisions
