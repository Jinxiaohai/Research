# particle_decay_MC
This is a Monte-Carlo simulator to perform resonance decays for unstable hadrons.
