fit_HBT_correlation
===================

The program read in the event-averaged HBT correlation function and perform fit to get the HBT radii
