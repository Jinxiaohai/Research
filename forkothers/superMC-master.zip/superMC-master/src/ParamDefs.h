#ifndef ugdModels
#define ugdModels
#define KLN 7
#define rcBK 100
#define rcBKalbacete 100
#define rcBKalbaceteSet2 101
#endif


#ifndef Amasses
#define Amasses
#define massU  238
#define massPb  208
#define massAu  197
#define massCu  63
#define massD  2
#define massP  1
#endif
